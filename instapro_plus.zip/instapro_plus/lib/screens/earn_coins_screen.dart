
import 'package:flutter/material.dart';

class EarnCoinsScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Earn Coins")),
      body: ListView(
        children: [
          TaskButton(label: "Follow User (+4 coins)"),
          TaskButton(label: "Like Post (+2 coins)"),
          TaskButton(label: "View Story (+1 coin)"),
          TaskButton(label: "Watch Reel (+1 coin)"),
          TaskButton(label: "Comment (+1 coin)"),
        ],
      ),
    );
  }
}

class TaskButton extends StatelessWidget {
  final String label;
  const TaskButton({required this.label});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(12.0),
      child: ElevatedButton(
        onPressed: () {},
        child: Text(label),
      ),
    );
  }
}
