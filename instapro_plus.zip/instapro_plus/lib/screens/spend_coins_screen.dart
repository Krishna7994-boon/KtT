
import 'package:flutter/material.dart';

class SpendCoinsScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Spend Coins")),
      body: ListView(
        children: [
          TaskButton(label: "Buy Followers (8 coins/follow)"),
          TaskButton(label: "Buy Likes (4 coins/like)"),
          TaskButton(label: "Buy Story Views (2 coins/view)"),
          TaskButton(label: "Buy Reels Views (2 coins/view)"),
          TaskButton(label: "Buy Comments (2 coins/comment)"),
        ],
      ),
    );
  }
}

class TaskButton extends StatelessWidget {
  final String label;
  const TaskButton({required this.label});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(12.0),
      child: ElevatedButton(
        onPressed: () {},
        child: Text(label),
      ),
    );
  }
}
