
import 'package:flutter/material.dart';

class AccountManagerScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Instagram Accounts")),
      body: ListView(
        children: [
          ListTile(title: Text("insta_user_1"), subtitle: Text("Active"), trailing: Icon(Icons.check_circle, color: Colors.green)),
          ListTile(title: Text("insta_user_2"), subtitle: Text("Inactive"), trailing: Icon(Icons.radio_button_unchecked)),
          Padding(
            padding: const EdgeInsets.all(12.0),
            child: ElevatedButton(
              onPressed: () {},
              child: Text("Add New Instagram Account"),
            ),
          )
        ],
      ),
    );
  }
}
